const contactForm = document.querySelector('#contact-form');
const formStatus = document.querySelector('#form-status');
const contactMethod = document.querySelector('#preferred-contact');
const contactInput = document.querySelector('#contact');
const BOT_URL = 'https://t.me/MoscowDealNavigatorBot';
const NAVIGATOR_ENTRIES = new Set(['start', 'buy', 'sell', 'invest']);

document.querySelectorAll('[data-navigator-entry]').forEach((link) => {
  const navigatorEntry = link.dataset.navigatorEntry;
  if (!NAVIGATOR_ENTRIES.has(navigatorEntry)) return;
  link.href = `${BOT_URL}?start=${encodeURIComponent(navigatorEntry)}`;
  link.target = '_blank';
  link.rel = 'noopener';
});

contactMethod?.addEventListener('change', () => {
  const label = document.querySelector('label[for="contact"]');
  if (label) label.textContent = `Контакт для связи (${contactMethod.value})`;
  contactInput?.setAttribute('autocomplete', contactMethod.value === 'Электронная почта' ? 'email' : 'tel');
});

contactForm?.addEventListener('submit', async (event) => {
  event.preventDefault();

  if (!contactForm.reportValidity()) {
    formStatus.textContent = 'Заполните поля и подтвердите согласие на передачу обращения.';
    return;
  }

  const formData = new FormData(contactForm);
  const submitButton = contactForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  formStatus.textContent = 'Отправляем обращение…';
  try {
    const response = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: formData.get('name'), method: formData.get('preferred-contact'), contact: formData.get('contact'),
        question: formData.get('question'), consent: formData.get('consent') === 'on'
      })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'Ошибка отправки');
    contactForm.reset();
    formStatus.textContent = result.message || 'Заявка отправлена Михаилу.';
  } catch (error) {
    formStatus.textContent = 'Не удалось отправить обращение. Попробуйте позже или напишите в мессенджер.';
  } finally {
    submitButton.disabled = false;
  }
});
