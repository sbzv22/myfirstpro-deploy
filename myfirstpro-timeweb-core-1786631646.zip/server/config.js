export function loadConfig(env) {
  for (const key of ['BOT_TOKEN', 'TELEGRAM_WEBHOOK_SECRET']) {
    if (!env[key]) throw new Error(`${key} is required`);
  }
  if (env.PUBLIC_BASE_URL && !env.PUBLIC_BASE_URL.startsWith('https://')) throw new Error('PUBLIC_BASE_URL must use HTTPS');
  return {
    port: Number(env.PORT || 3000),
    botToken: env.BOT_TOKEN,
    webhookSecret: env.TELEGRAM_WEBHOOK_SECRET,
    adminChatId: env.ADMIN_CHAT_ID || null,
    publicBaseUrl: env.PUBLIC_BASE_URL?.replace(/\/$/, '') || null
  };
}
