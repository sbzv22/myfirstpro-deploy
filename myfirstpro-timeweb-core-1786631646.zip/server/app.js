import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { timingSafeEqual } from 'node:crypto';
import { handleUpdate } from './telegram.js';

const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.jpg': 'image/jpeg' };
const text = (response, status, body) => { response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); response.end(JSON.stringify(body)); };
const safeEqual = (a, b) => { const x = Buffer.from(a || ''), y = Buffer.from(b || ''); return x.length === y.length && timingSafeEqual(x, y); };

async function bodyOf(request, limit = 16_384) {
  const chunks = []; let size = 0;
  for await (const chunk of request) { size += chunk.length; if (size > limit) throw new Error('Body too large'); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new Error('Invalid JSON'); }
}

function validContact(payload) {
  const methods = new Set(['Telegram', 'WhatsApp', 'Звонок', 'Электронная почта']);
  return payload && payload.consent === true && typeof payload.name === 'string' && payload.name.trim().length >= 1 && payload.name.trim().length <= 80 && methods.has(payload.method) && typeof payload.contact === 'string' && payload.contact.trim().length >= 3 && payload.contact.trim().length <= 160 && (!payload.question || (typeof payload.question === 'string' && payload.question.length <= 1000));
}

export function createApp({ config, store, telegram, staticDir, now = () => Date.now() }) {
  const rate = new Map();
  const canSubmit = (ip) => { const cutoff = now() - 600_000; const entries = (rate.get(ip) || []).filter((time) => time > cutoff); if (entries.length >= 5) return false; entries.push(now()); rate.set(ip, entries); return true; };
  return createServer(async (request, response) => {
    const url = new URL(request.url, 'http://localhost');
    try {
      if (request.method === 'POST' && url.pathname === '/telegram/webhook') {
        if (!safeEqual(request.headers['x-telegram-bot-api-secret-token'], config.webhookSecret)) return text(response, 401, { error: 'Unauthorized' });
        const update = await bodyOf(request); await handleUpdate({ update, store, config, telegram }); return text(response, 200, { ok: true });
      }
      if (request.method === 'POST' && url.pathname === '/api/contact') {
        if (!canSubmit(request.socket.remoteAddress || 'unknown')) return text(response, 429, { error: 'Попробуйте позже.' });
        const payload = await bodyOf(request);
        if (!validContact(payload)) return text(response, 400, { error: 'Проверьте контакт и подтвердите согласие на передачу заявки.' });
        if (!config.adminChatId) return text(response, 503, { error: 'Приём заявок временно недоступен. Попробуйте позже.' });
        const lead = ['Новая заявка с сайта', '', `Имя: ${payload.name.trim()}`, `Способ связи: ${payload.method}`, `Контакт: ${payload.contact.trim()}`, `Вопрос: ${(payload.question || 'Не указан').trim()}`].join('\n');
        await telegram.sendMessage(config.adminChatId, lead); return text(response, 202, { ok: true, message: 'Заявка отправлена Михаилу.' });
      }
      if (request.method === 'GET') {
        const relative = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
        if (!['index.html', 'styles.css', 'app.js', 'assets/mikhail-slobodskoy.jpg'].includes(relative) || normalize(relative).includes('..')) return text(response, 404, { error: 'Not found' });
        const file = await readFile(join(staticDir, relative)); response.writeHead(200, { 'content-type': types[extname(relative)], 'x-content-type-options': 'nosniff' }); response.end(file); return;
      }
      text(response, 405, { error: 'Method not allowed' });
    } catch (error) {
      const status = /Invalid JSON|Body too large/.test(error.message) ? 400 : 503;
      text(response, status, { error: status === 400 ? 'Некорректный запрос.' : 'Сервис временно недоступен. Попробуйте позже.' });
    }
  });
}
