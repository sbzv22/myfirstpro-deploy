const objectOptions = ['Квартира', 'Загородный объект', 'Коммерческая недвижимость', 'Пока не определился'];
const areaOptions = ['Москва', 'Московская область', 'Пока выбираю'];
const channelOptions = ['Telegram', 'WhatsApp', 'Звонок', 'Электронная почта'];

const common = [
  ['object', 'Какой тип объекта рассматриваете?', objectOptions],
  ['area', 'Где планируется сделка?', areaOptions]
];

export const routes = {
  buy: [
    ['goal', 'Какова ваша цель?', ['Покупка для переезда', 'Покупка для сохранения капитала', 'Другое']],
    ...common,
    ['timeline', 'Когда хотите начать?', ['До трёх месяцев', 'В течение года', 'Пока изучаю рынок']],
    ['priority', 'Что для вас сейчас важнее?', ['Переезд', 'Стоимость', 'Ликвидность', 'Безопасность сделки', 'Другое']],
    ['stage', 'На каком вы этапе?', ['Есть варианты', 'Только начинаю', 'Нужна стратегия']],
    ['channel', 'Как удобнее продолжить разговор?', channelOptions]
  ],
  sell: [
    ['goal', 'Какова ваша цель?', ['Продажа объекта', 'Продажа с последующей покупкой', 'Другое']],
    ...common,
    ['timeline', 'Когда хотите начать?', ['До трёх месяцев', 'В течение года', 'Пока изучаю рынок']],
    ['priority', 'Что для вас сейчас важнее?', ['Стоимость', 'Срок', 'Ликвидность', 'Безопасность сделки', 'Другое']],
    ['stage', 'На каком вы этапе?', ['Есть объект', 'Только начинаю', 'Нужна стратегия']],
    ['channel', 'Как удобнее продолжить разговор?', channelOptions]
  ],
  invest: [
    ['goal', 'Какова главная цель вложения?', ['Сохранить капитал', 'Получить доход', 'Диверсифицировать активы', 'Другое']],
    ...common,
    ['timeline', 'Какой горизонт вложения?', ['До трёх лет', 'От трёх до семи лет', 'Более семи лет']],
    ['risk', 'Какой уровень неопределённости для вас приемлем?', ['Низкий', 'Средний', 'Высокий']],
    ['stage', 'На каком вы этапе?', ['Есть объект', 'Есть варианты', 'Только начинаю', 'Нужна стратегия']],
    ['channel', 'Как удобнее продолжить разговор?', channelOptions]
  ]
};

export function startRoute(route) {
  const questions = routes[route];
  if (!questions) throw new Error('Unknown route');
  return { route, questions, step: 0, answers: {} };
}

export function answerSession(session, value) {
  const question = session.questions[session.step];
  if (!question) return { session, complete: true };
  return {
    session: { ...session, step: session.step + 1, answers: { ...session.answers, [question[0]]: String(value).slice(0, 160) } },
    complete: session.step + 1 >= session.questions.length
  };
}

export function currentQuestion(session) {
  const question = session.questions[session.step];
  return question ? { key: question[0], prompt: question[1], options: question[2] } : null;
}

export function buildCard(session) {
  const a = session.answers;
  const missing = ['area', 'timeline', 'stage'].filter((key) => !a[key] || /не определ|выбираю/i.test(a[key]));
  const attention = session.route === 'invest'
    ? 'Соответствие цели, горизонта, условий сделки и допустимой неопределённости.'
    : 'Документы, ликвидность, условия сделки и соответствие объекта вашей задаче.';
  return {
    disclaimer: 'Это предварительный ориентир по вашим ответам. Он не является юридическим заключением, оценкой объекта, инвестиционной рекомендацией или обещанием результата.',
    title: 'Ваша предварительная карточка',
    summary: `${a.goal || 'Задача'} · ${a.object || 'тип объекта уточняется'} · ${a.area || 'география уточняется'}.`,
    clarifications: missing.length ? `Важно уточнить: ${missing.map((key) => ({ area: 'географию', timeline: 'срок', stage: 'текущий этап' })[key]).join(', ')}.` : 'Ключевые параметры указаны; их стоит проверить перед предметным разговором.',
    attention,
    nextStep: 'Если захотите, Михаил сможет обсудить с вами следующий шаг с учётом этой карточки.'
  };
}
