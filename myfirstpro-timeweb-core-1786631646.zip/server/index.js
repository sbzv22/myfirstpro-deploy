import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadConfig } from './config.js';
import { createSessionStore } from './sessions.js';
import { createTelegramClient } from './telegram.js';
import { createApp } from './app.js';

const config = loadConfig(process.env);
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const app = createApp({ config, store: createSessionStore(), telegram: createTelegramClient({ botToken: config.botToken }), staticDir: join(root, 'site') });
app.listen(config.port, () => console.log(`Server listening on ${config.port}`));
