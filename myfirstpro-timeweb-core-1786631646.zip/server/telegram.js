import { answerSession, buildCard, currentQuestion, startRoute } from './questions.js';

const routes = ['buy', 'sell', 'invest'];
const buttons = (rows) => ({ inline_keyboard: rows.map((row) => [row]) });
const actionButton = (text, data) => ({ text, callback_data: data });

export function createTelegramClient({ botToken, fetchImpl = fetch }) {
  return {
    async sendMessage(chatId, text, replyMarkup) {
      const response = await fetchImpl(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text, reply_markup: replyMarkup, disable_web_page_preview: true })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error('Telegram delivery failed');
    }
  };
}

function questionMarkup(question) {
  return buttons(question.options.map((option, index) => actionButton(option, `answer:${index}`)));
}

function cardText(card) {
  return [card.disclaimer, '', card.title, `Ваша задача: ${card.summary}`, `Что важно уточнить: ${card.clarifications}`, `На что обратить внимание: ${card.attention}`, `Следующий шаг: ${card.nextStep}`].join('\n');
}

function contactPrompt(channel) {
  return {
    WhatsApp: 'Введите номер WhatsApp, по которому Михаил сможет с вами связаться.',
    'Звонок': 'Введите номер телефона для звонка.',
    'Электронная почта': 'Введите адрес электронной почты для ответа.'
  }[channel] || null;
}

function isContactValid(channel, contact) {
  if (channel === 'Электронная почта') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact);
  return /^[+()\d\s-]{7,32}$/.test(contact);
}

function leadText({ user, session, contact }) {
  return ['Новая заявка из навигатора', '', `Клиент: ${user.id}${user.username ? ` (@${user.username})` : ''}`, `Предпочтительный канал: ${session.answers.channel || 'не указан'}`, `Контакт: ${contact}`, '', cardText(session.card)].join('\n');
}

async function showQuestion(chatId, session, telegram) {
  const question = currentQuestion(session);
  await telegram.sendMessage(chatId, question.prompt, questionMarkup(question));
}

export async function handleUpdate({ update, store, config, telegram }) {
  if (!update || !store.consumeUpdateId(update.update_id)) return { status: 'ignored' };
  const callback = update.callback_query;
  const message = update.message;
  const chatId = callback?.message?.chat?.id ?? message?.chat?.id;
  const user = callback?.from ?? message?.from ?? { id: chatId };
  if (chatId === undefined) return { status: 'ignored' };

  if (message?.text) {
    const [command, argument] = message.text.trim().split(/\s+/, 2);
    if (command === '/myid') { await telegram.sendMessage(chatId, `Ваш технический chat ID: ${chatId}`); return { status: 'handled' }; }
    if (command === '/cancel') { store.delete(chatId); await telegram.sendMessage(chatId, 'Маршрут отменён. Когда будете готовы, выберите покупку, продажу или инвестицию.'); return { status: 'handled' }; }
    if (command === '/start') {
      const route = routes.includes(argument) ? argument : null;
      if (route) { const session = startRoute(route); store.set(chatId, session); await telegram.sendMessage(chatId, 'Я задам несколько коротких вопросов, чтобы собрать предварительный маршрут. Это займёт около двух минут.'); await showQuestion(chatId, session, telegram); }
      else await telegram.sendMessage(chatId, 'С чем помочь?', buttons(routes.map((routeName) => actionButton({ buy: 'Купить', sell: 'Продать', invest: 'Инвестировать' }[routeName], `route:${routeName}`))));
      return { status: 'handled' };
    }
    const pending = store.get(chatId);
    if (pending?.contactPending) {
      const contact = message.text.trim();
      const channel = pending.answers.channel;
      if (!isContactValid(channel, contact)) {
        await telegram.sendMessage(chatId, channel === 'Электронная почта' ? 'Проверьте адрес электронной почты и отправьте его ещё раз.' : 'Проверьте номер и отправьте его ещё раз.');
        return { status: 'handled' };
      }
      if (!config.adminChatId) {
        store.delete(chatId); await telegram.sendMessage(chatId, 'Передача обращения сейчас временно недоступна. Попробуйте позже или свяжитесь с Михаилом напрямую.'); return { status: 'handled' };
      }
      await telegram.sendMessage(config.adminChatId, leadText({ user, session: pending, contact }));
      store.delete(chatId); await telegram.sendMessage(chatId, 'Карточка и контакт переданы Михаилу. Он продолжит разговор в выбранном вами формате.');
      return { status: 'handled' };
    }
    await telegram.sendMessage(chatId, 'Используйте /start, чтобы начать, или /cancel, чтобы отменить маршрут.');
    return { status: 'handled' };
  }

  if (!callback?.data) return { status: 'ignored' };
  if (callback.data.startsWith('route:')) {
    const route = callback.data.slice(6);
    if (!routes.includes(route)) return { status: 'ignored' };
    const session = startRoute(route); store.set(chatId, session);
    await telegram.sendMessage(chatId, 'Я задам несколько коротких вопросов, чтобы собрать предварительный маршрут. Это займёт около двух минут.');
    await showQuestion(chatId, session, telegram);
    return { status: 'handled' };
  }
  const session = store.get(chatId);
  if (!session) { await telegram.sendMessage(chatId, 'Маршрут уже завершён или истёк. Нажмите /start, чтобы начать снова.'); return { status: 'handled' }; }
  if (callback.data.startsWith('answer:')) {
    const option = currentQuestion(session)?.options[Number(callback.data.slice(7))];
    if (!option) return { status: 'ignored' };
    const next = answerSession(session, option);
    store.set(chatId, next.session);
    if (!next.complete) await showQuestion(chatId, next.session, telegram);
    else {
      const card = buildCard(next.session); store.set(chatId, { ...next.session, card });
      await telegram.sendMessage(chatId, cardText(card));
      await telegram.sendMessage(chatId, 'Передать Михаилу эту карточку и контакт, который вы укажете для выбранного способа связи?', buttons([actionButton('Согласен передать', 'consent:yes'), actionButton('Не передавать', 'consent:no')]));
    }
    return { status: 'handled' };
  }
  if (callback.data === 'consent:no') { store.delete(chatId); await telegram.sendMessage(chatId, 'Хорошо. Карточка не передана. Вы можете начать заново через /start.'); return { status: 'handled' }; }
  if (callback.data === 'consent:yes') {
    if (!session.card || !config.adminChatId) { store.delete(chatId); await telegram.sendMessage(chatId, 'Передача обращения сейчас временно недоступна. Попробуйте позже или свяжитесь с Михаилом напрямую.'); return { status: 'handled' }; }
    const prompt = contactPrompt(session.answers.channel);
    if (prompt) {
      store.set(chatId, { ...session, contactPending: true }); await telegram.sendMessage(chatId, prompt); return { status: 'handled' };
    }
    const contact = user.username ? `@${user.username}` : `Telegram ID ${user.id}`;
    await telegram.sendMessage(config.adminChatId, leadText({ user, session, contact }));
    store.delete(chatId); await telegram.sendMessage(chatId, 'Карточка передана Михаилу. Он продолжит разговор в Telegram.');
    return { status: 'handled' };
  }
  return { status: 'ignored' };
}
