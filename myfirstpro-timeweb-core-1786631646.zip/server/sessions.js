export function createSessionStore({ now = () => Date.now(), ttlMs = 20 * 60_000, maxSessions = 1000, maxSeenUpdates = 5000 } = {}) {
  const sessions = new Map();
  const seen = new Map();
  const purge = () => {
    const cutoff = now() - ttlMs;
    for (const [key, item] of sessions) if (item.updatedAt < cutoff) sessions.delete(key);
    for (const [key, createdAt] of seen) if (createdAt < cutoff) seen.delete(key);
  };
  return {
    get(key) { purge(); return sessions.get(String(key))?.session || null; },
    set(key, session) { purge(); if (sessions.size >= maxSessions && !sessions.has(String(key))) sessions.delete(sessions.keys().next().value); sessions.set(String(key), { session, updatedAt: now() }); },
    delete(key) { sessions.delete(String(key)); },
    consumeUpdateId(id) { purge(); const key = String(id); if (seen.has(key)) return false; if (seen.size >= maxSeenUpdates) seen.delete(seen.keys().next().value); seen.set(key, now()); return true; },
    purge
  };
}
